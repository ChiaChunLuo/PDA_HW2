#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <math.h>
#include <time.h>
#include <sys/time.h>
using namespace std;

typedef struct BUCKET{
    int first_cell;
}bucket;


typedef struct ID{
    char name[15];
}id;

typedef struct CELL{
    id ID;
    char group;
    char lock;
    int weight;
    int gain;
    int prev;
    int next;
    int p;
    vector<int> nets;
}cell;

typedef struct NET{
    id ID;
    vector<int> cells;
    char cut;
    int g[2];
}net;

int find_cell(id, int, int );
int find_max_gains(int);
int order_by_size(const void *, const void * );
int order_by_ID(const void *, const void * );
int count_cutsize();
void update_cell_gain(int);
void update_bucketlist(int, int);
int maxi(int, int);
void cellgain_bucketlist_init();
int FM();

cell *cell_list;
net *net_list;
bucket *blist0;
bucket *blist1;
int cell_num;
int net_num;
int total_size;
int Pmax;
int g0_size;
int g1_size;
int cut_size;
char buffer[15];

int main(int argc, char* argv[]){
    /// input : cell
    cell_list = (cell *)malloc(sizeof(cell)*100000000);
    struct timeval ins, ine;
    gettimeofday(&ins, NULL);
    FILE *fcell;
    fcell = fopen(argv[1],"r");
    cell_num = 0;
    total_size = 0;
    while(fscanf(fcell, "%s", buffer)!=EOF){
        strcpy(cell_list[cell_num].ID.name, buffer);
        cell_list[cell_num].lock = 'f';
        cell_list[cell_num].group = '1';
        cell_list[cell_num].p = 0;
        cell_list[cell_num].nets.clear();
        fscanf(fcell, "%d", &cell_list[cell_num].weight);
        cell_list[cell_num].next = -1;
        cell_list[cell_num].prev = -1;
        total_size = total_size + cell_list[cell_num].weight;
        cell_num++;
    }
    printf("cell_num : %d\n",cell_num);
    printf("total_size :%d\n",total_size);
    //qsort(cell_list, cell_num, sizeof(cell), order_by_size);
    int index_f = 0,index_b = cell_num-1;
    int i = 0;
    g0_size = 0, g1_size = 0;//total_size;
    while(1){
        if(index_b<index_f){
            break;
        }
        if(index_b==index_f){
            if(g0_size<=g1_size){
                cell_list[index_f].group='0';
                g0_size += cell_list[index_f].weight;

            }else{
                cell_list[index_f].group='1';
                g1_size += cell_list[index_f].weight;
            }
            break;
        }
        if(index_f<index_b){
            if(g0_size<=g1_size){
                cell_list[index_f].group='0';
                g0_size += cell_list[index_f].weight;
                index_f++;
            }else{
                cell_list[index_b].group='1';
                g1_size += cell_list[index_b].weight;
                index_b--;
            }
        }
    }
   // printf("wow\n");
    /*while(abs(g0_size-g1_size) >= (int)(total_size/10)){
        g0_size += cell_list[i].weight;
        g1_size -= cell_list[i].weight;
        cell_list[i].group = '0';
        i++;
    }*/
    qsort(cell_list, cell_num, sizeof(cell), order_by_ID);

    /// input : net
    net_list = (net *)malloc(sizeof(net)*100000000);
    FILE *fnet;
    net_num = 0;
    Pmax = 0;
    fnet = fopen(argv[2],"r");
    while(fscanf(fnet, "%s", buffer)!=EOF){
        fscanf(fnet, "%s", net_list[net_num].ID.name);
        fscanf(fnet, "%s", buffer);
        net_list[net_num].g[0] = 0;
        net_list[net_num].g[1] = 0;
        while(1){
            fscanf(fnet, "%s", buffer);
            if(strcmp(buffer, "}")==0)
                break;
            vector<int>::iterator cell_i;
            int duplicate = 0;
            id t;
            strcpy(t.name, buffer);
            int index = find_cell(t, 0, cell_num-1);
            for(cell_i = net_list[net_num].cells.begin(); cell_i != net_list[net_num].cells.end(); cell_i++){
                if(index == *cell_i){
                    duplicate = 1;
                    break;
                }
            }
            if(duplicate!=1){
                net_list[net_num].cells.push_back(index);
                net_list[net_num].cells.shrink_to_fit();
                cell_list[index].nets.push_back(net_num);
                cell_list[index].nets.shrink_to_fit();
                cell_list[index].p++;
                if(cell_list[index].group=='0')
                    net_list[net_num].g[0]++;
                else if(cell_list[index].group=='1')
                    net_list[net_num].g[1]++;
                if(cell_list[index].p > Pmax)
                    Pmax = cell_list[index].p;
            }
        }
        net_num++;
    }
    gettimeofday(&ine, NULL);
    if(ine.tv_usec < ins.tv_usec){
        ine.tv_usec += 1000000;
        ine.tv_sec--;
    }
    printf("I time : %d s %d ms %d us\n", ine.tv_sec-ins.tv_sec, (ine.tv_usec-ins.tv_usec)/1000, (ine.tv_usec-ins.tv_usec)%1000);

    /// construct bucket list
    blist0 = (bucket *)malloc(sizeof(bucket)*(2*Pmax+1));
    blist1 = (bucket *)malloc(sizeof(bucket)*(2*Pmax+1));
    for(i=0; i<2*Pmax+1; i++){
        blist0[i].first_cell = -1;
        blist1[i].first_cell = -1;
    }

    /// F(uck) M(other) algorithm
    struct timeval ans, ane;
    gettimeofday(&ans, NULL);
    int r=1;
    while(1){
        int end_or_not = FM();
        r++;
        printf("r = %d\n",r);
        if(end_or_not==0)
            break;
        if(r==15)
            break;
    }
    gettimeofday(&ane, NULL);
    if(ane.tv_usec < ans.tv_usec){
        ane.tv_usec += 1000000;
        ane.tv_sec--;
    }
    printf("ALGO time : %d s %d ms %d us\n", ane.tv_sec-ans.tv_sec, (ane.tv_usec-ans.tv_usec)/1000, (ane.tv_usec-ans.tv_usec)%1000);

    ///test
    cellgain_bucketlist_init();
    cut_size = count_cutsize();
    printf("final cut size = %d\n",cut_size);
    printf("rounds = %d\n",r);
    printf("g0 : %d  g1 : %d g0-g1=%d  %d\n",g0_size,g1_size,abs(g0_size-g1_size),(int)(total_size/10));

    /// output
    struct timeval ons, one;
    gettimeofday(&ons, NULL);
    char output_file_name[100]="../output/";
    for(i=10; ;i++){
        if(argv[1][i+3]=='.'){
            output_file_name[i]='.';
            output_file_name[i+1]='o';
            output_file_name[i+2]='u';
            output_file_name[i+3]='t';
            break;
        }
        output_file_name[i]=argv[1][i+3];
    }
    FILE *output;
    printf("out name : %s\n",output_file_name);
    output = fopen(output_file_name,"w");
    fprintf(output,"cut_size %d\n",cut_size);
    int A=0, B=0;
    for(i=0; i<cell_num; i++){
        if(cell_list[i].group=='0')
            A++;
        else
            B++;
    }
    fprintf(output,"A %d\n",A);
    for(i=0; i<cell_num; i++){
        if(cell_list[i].group=='0')
            fprintf(output,"%s\n",cell_list[i].ID.name);
    }
    fprintf(output,"B %d\n",B);
    for(i=0; i<cell_num; i++){
        if(cell_list[i].group=='1')
            fprintf(output,"%s\n",cell_list[i].ID.name);
    }
    gettimeofday(&one, NULL);
    if(one.tv_usec < ons.tv_usec){
        one.tv_usec += 1000000;
        one.tv_sec--;
    }
    printf("O time : %d s %d ms %d us\n", one.tv_sec-ons.tv_sec, (one.tv_usec-ons.tv_usec)/1000, (one.tv_usec-ons.tv_usec)%1000);
    return 0;
}
int FM(){
    cellgain_bucketlist_init();
    int i, j;
    int round = 0;
    int max_round = 0;
    int ps = 0;
    int max_ps = (Pmax+1)*-1;
    vector<int> movelist;
    movelist.clear();
    for(i=0; i<cell_num; i++){
        int max_gain = maxi(find_max_gains(0), find_max_gains(1));
        int find_one = 0;
        //for(j = max_gain; j >= Pmax*-1; j--){
        for(j = max_gain; j >= Pmax*-1 && j>= max_gain-10; j--){
            int pointer;
            pointer = blist0[j+Pmax].first_cell;
            while(pointer!=-1){
                if(cell_list[pointer].lock=='f' && abs((g0_size-cell_list[pointer].weight)-(g1_size+cell_list[pointer].weight))<(int)(total_size/10)){
                    movelist.push_back(pointer);
                    movelist.shrink_to_fit();
                    g0_size = g0_size - cell_list[pointer].weight;
                    g1_size = g1_size + cell_list[pointer].weight;
                    round++;
                    ps += j;
                    if(ps > max_ps){
                        max_ps = ps;
                        max_round = round;
                    }
                    update_cell_gain(pointer);
                    find_one = 1;
                }else{
                    pointer = cell_list[pointer].next;
                }
                if(find_one)
                    break;
            }
            if(find_one)
                break;
            pointer = blist1[j+Pmax].first_cell;
            while(pointer!=-1){
                if(cell_list[pointer].lock=='f' && abs((g1_size-cell_list[pointer].weight)-(g0_size+cell_list[pointer].weight))<=(int)(total_size/10)){
                    movelist.push_back(pointer);
                    movelist.shrink_to_fit();
                    g1_size =  g1_size - cell_list[pointer].weight;
                    g0_size =  g0_size + cell_list[pointer].weight;
                    round++;
                    ps += j;
                    if(ps > max_ps){
                        max_ps = ps;
                        max_round = round;
                    }
                    update_cell_gain(pointer);
                    find_one = 1;
                }else{
                    pointer = cell_list[pointer].next;
                }
                if(find_one)
                    break;
            }
            if(find_one)
                break;
        }
        /// cant find anymore
        if(find_one==0)
            break;
    }
    vector<int>::iterator id_i;
    /// if total gain<0 ,we give up all movement in this pass, and end the fucking algorithm
    if(max_ps<=0){
        for(id_i = movelist.begin(); id_i != movelist.end(); id_i++){
            if(cell_list[*id_i].group=='0'){
                g1_size = g1_size + cell_list[*id_i].weight;
                g0_size = g0_size - cell_list[*id_i].weight;
                cell_list[*id_i].group='1';
            }
            else if(cell_list[*id_i].group=='1'){
                g0_size = g0_size + cell_list[*id_i].weight;
                g1_size = g1_size - cell_list[*id_i].weight;
                cell_list[*id_i].group='0';
            }
        }
        return 0;
    }
    i = 0;
    for(id_i = movelist.begin(); id_i != movelist.end(); id_i++){
        if(i >= max_round){
            if(cell_list[*id_i].group=='0'){
                g1_size = g1_size + cell_list[*id_i].weight;
                g0_size = g0_size - cell_list[*id_i].weight;
                cell_list[*id_i].group='1';
            }
            else if(cell_list[*id_i].group=='1'){
                g0_size = g0_size + cell_list[*id_i].weight;
                g1_size = g1_size - cell_list[*id_i].weight;
                cell_list[*id_i].group='0';
            }
        }
        i++;
    }
    return 1;
}
void update_cell_gain(int in){
    int F, T;
    cell_list[in].lock = 'l';
    if(cell_list[in].group=='0'){
        F = 0;
        T = 1;
        cell_list[in].group = '1';
    }else if(cell_list[in].group=='1'){
        F = 1;
        T = 0;
        cell_list[in].group = '0';
    }
    vector<int>::iterator id_n;
    for(id_n = cell_list[in].nets.begin(); id_n != cell_list[in].nets.end(); id_n++){
        vector<int>::iterator cell_n;
        if(net_list[*id_n].g[T]==0){
            for(cell_n = net_list[*id_n].cells.begin(); cell_n != net_list[*id_n].cells.end(); cell_n++){
                if(cell_list[*cell_n].lock=='f'){
                    cell_list[*cell_n].gain++;
                    update_bucketlist(*cell_n, cell_list[*cell_n].gain-1);
                }
            }
        }else if(net_list[*id_n].g[T]==1){
            for(cell_n = net_list[*id_n].cells.begin(); cell_n != net_list[*id_n].cells.end(); cell_n++){
                if(cell_list[*cell_n].lock=='f' && cell_list[*cell_n].group-'0' == T){
                    cell_list[*cell_n].gain--;
                    update_bucketlist(*cell_n, cell_list[*cell_n].gain+1);
                }
            }
        }
        net_list[*id_n].g[F]--;
        net_list[*id_n].g[T]++;
        if(net_list[*id_n].g[F]==0){
            for(cell_n = net_list[*id_n].cells.begin(); cell_n != net_list[*id_n].cells.end(); cell_n++){
                if(cell_list[*cell_n].lock=='f'){
                    cell_list[*cell_n].gain--;
                    update_bucketlist(*cell_n, cell_list[*cell_n].gain+1);
                }
            }
        }else if(net_list[*id_n].g[F]==1){
            for(cell_n = net_list[*id_n].cells.begin(); cell_n != net_list[*id_n].cells.end(); cell_n++){
                if(cell_list[*cell_n].lock=='f' && cell_list[*cell_n].group-'0' == F){
                    cell_list[*cell_n].gain++;
                    update_bucketlist(*cell_n, cell_list[*cell_n].gain-1);
                }
            }
        }
    }
    return ;
}
void update_bucketlist(int in, int old_gain){
    if(cell_list[in].prev==-1){
        if(cell_list[in].group=='0'){
            blist0[old_gain+Pmax].first_cell = cell_list[in].next;
            if(cell_list[in].next!=-1)
                cell_list[cell_list[in].next].prev = -1;
        }else if(cell_list[in].group=='1'){
            blist1[old_gain+Pmax].first_cell = cell_list[in].next;
            if(cell_list[in].next!=-1)
                cell_list[cell_list[in].next].prev = -1;
        }
    }else if(cell_list[in].prev!=-1){
        cell_list[cell_list[in].prev].next = cell_list[in].next;
        if(cell_list[in].next!=-1)
            cell_list[cell_list[in].next].prev = cell_list[in].prev;
    }
    cell_list[in].next = -1;
    cell_list[in].prev = -1;
    if(cell_list[in].group=='0'){
        if(blist0[cell_list[in].gain+Pmax].first_cell==-1){
            blist0[cell_list[in].gain+Pmax].first_cell = in;
        }else if(blist0[cell_list[in].gain+Pmax].first_cell!=-1){
            cell_list[blist0[cell_list[in].gain+Pmax].first_cell].prev = in;
            cell_list[in].next =  blist0[cell_list[in].gain+Pmax].first_cell;
            blist0[cell_list[in].gain+Pmax].first_cell = in;
        }
    }else if(cell_list[in].group=='1'){
        if(blist1[cell_list[in].gain+Pmax].first_cell==-1){
            blist1[cell_list[in].gain+Pmax].first_cell = in;
        }else if(blist1[cell_list[in].gain+Pmax].first_cell!=-1){
            cell_list[blist1[cell_list[in].gain+Pmax].first_cell].prev = in;
            cell_list[in].next =  blist1[cell_list[in].gain+Pmax].first_cell;
            blist1[cell_list[in].gain+Pmax].first_cell = in;
        }
    }
    return ;
}
void cellgain_bucketlist_init(){
    int i;
    /// clear two bucket lists
    for(i=0; i<(2*Pmax+1); i++){
        blist0[i].first_cell = -1;
        blist1[i].first_cell = -1;
    }
    /// free all cells and updates their gains
    for(i=0; i<net_num; i++){
        net_list[i].g[0] = 0;
        net_list[i].g[1] = 0;
        vector<int>::iterator id_i;
        for(id_i = net_list[i].cells.begin(); id_i != net_list[i].cells.end(); id_i++)
            net_list[i].g[cell_list[*id_i].group-'0']++;
    }
    for(i=0; i<cell_num; i++){
        cell_list[i].lock = 'f';
        cell_list[i].gain = 0;
        cell_list[i].next = -1;
        cell_list[i].prev = -1;
        int F, T;
        if(cell_list[i].group=='0'){
            F = 0;
            T = 1;
        }else if(cell_list[i].group=='1'){
            F = 1;
            T = 0;
        }
        vector<int>::iterator id_i;
        for(id_i = cell_list[i].nets.begin(); id_i != cell_list[i].nets.end(); id_i++){
            if(net_list[*id_i].g[F]==1)
                cell_list[i].gain++;
            if(net_list[*id_i].g[T]==0)
                cell_list[i].gain--;
        }
    }

    /// rebuild bucket lists
    for(i=0; i<cell_num; i++){
        if(cell_list[i].group=='0'){
            if(blist0[cell_list[i].gain+Pmax].first_cell != -1){
                cell_list[i].next = blist0[cell_list[i].gain+Pmax].first_cell;
                cell_list[blist0[cell_list[i].gain+Pmax].first_cell].prev = i;
            }else{
                cell_list[i].next = -1;
                cell_list[i].prev = -1;
            }
            blist0[cell_list[i].gain+Pmax].first_cell = i;
        }else if(cell_list[i].group=='1'){
            if(blist1[cell_list[i].gain+Pmax].first_cell != -1){
                cell_list[i].next = blist1[cell_list[i].gain+Pmax].first_cell;
                cell_list[blist1[cell_list[i].gain+Pmax].first_cell].prev = i;
            }else{
                cell_list[i].next = -1;
                cell_list[i].prev = -1;
            }
            blist1[cell_list[i].gain+Pmax].first_cell = i;
        }
    }
    return ;
}
int count_cutsize(){
    int i;
    int csize = 0;
    for(i=0; i<net_num; i++){
        if(net_list[i].g[0]!=0 && net_list[i].g[1]!=0)
            csize++;
    }
    return csize;
}
int find_cell(id in, int s, int d){
    int mid = (s + d) / 2;
    if(strcmp(cell_list[mid].ID.name, in.name)==0) return mid;
    if(strcmp(cell_list[mid].ID.name, in.name)<0) return find_cell(in, mid+1, d);
    if(strcmp(cell_list[mid].ID.name, in.name)>0) return find_cell(in, s, mid-1);
}
int order_by_size(const void * a, const void * b){
    cell *ap;
    cell *bp;
    ap = (cell *)a;
    bp = (cell *)b;
    if(ap->weight < bp->weight) return -1;
    if(ap->weight == bp->weight && strcmp(ap->ID.name,bp->ID.name)<0) return -1;
    if(ap->weight == bp->weight && strcmp(ap->ID.name,bp->ID.name)>0) return 1;
    if(ap->weight > bp->weight) return 1;
}

int order_by_ID(const void * a, const void * b){
    cell *ap;
    cell *bp;
    ap = (cell *)a;
    bp = (cell *)b;
    if(strcmp(ap->ID.name, bp->ID.name)<0) return -1;
    if(strcmp(ap->ID.name, bp->ID.name)==0) return 0;
    if(strcmp(ap->ID.name, bp->ID.name)>0) return 1;
}
int maxi(int a, int b){
    if(a>=b) return a;
    if(b>a) return b;
}
int find_max_gains(int g){
    int i;
    if(g==0){
        for(i=Pmax*2; i>=0; i--){
            if(blist0[i].first_cell!=-1)
                return i-Pmax;
        }
    }else if(g==1){
        for(i=Pmax*2; i>=0; i--){
            if(blist1[i].first_cell!=-1)
                return i-Pmax;
        }
    }
}
